import { Injectable } from '@angular/core';
import * as S3 from 'aws-sdk/clients/s3';

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  s3 = new S3({
    accessKeyId: 'AKIA2LMVRCLTP6R7QJUC',
    secretAccessKey: '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',
    region: 'us-east-1',
  });

  constructor() {}

  getImage() {
    var bucketParams = {
      Bucket: 'leo-private-test',
    };

    // Call S3 to obtain a list of the objects in the bucket
    this.s3.listObjects(bucketParams, function (err, data) {
      if (err) {
        console.log('Error', err);
      } else {
        console.log('Success', data);
      }
    });

    // this.s3.getObject()
  }
}
